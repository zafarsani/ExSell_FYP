package com.example.exsell;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.exsell.data.model.ProductModel;
import com.example.exsell.databinding.ActivityCartBinding;
import com.example.exsell.databinding.FragmentDashboardBinding;
import com.example.exsell.ui.dashboard.DashboardFragment;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class ActivityCart extends AppCompatActivity implements MyAdapter.OnItemClickListener {


    ProgressDialog progressDialog ;

    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;

    private StorageReference storageReference;
    private FirebaseStorage firebaseStorage;

    private List<ProductModel> productModelList;

    private FirebaseFirestore firebaseFirestore;

    private MyAdapter myAdapter;

    ActivityCartBinding binding;
    private SharedPrefManager sharedPrefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        binding = ActivityCartBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);


        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();
        productModelList = new ArrayList<>();
        sharedPrefManager = new SharedPrefManager(ActivityCart.this);

        binding.rvProducts.setLayoutManager(new LinearLayoutManager(ActivityCart.this));
        progressDialog = new ProgressDialog(ActivityCart.this);
        getProducts();

    }


    public void deleteProduct(int position, ProductModel productItem) {

        Toast.makeText(this, "debug1", Toast.LENGTH_SHORT).show();
        progressDialog.show();
        firebaseFirestore.collection("Cart").document(productItem.getDocID()).delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        progressDialog.dismiss();
                        myAdapter.notifyItemRemoved(position);
                        Toast.makeText(ActivityCart.this, "Deleted !", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    public void getProducts() {
        firebaseFirestore.collection("Cart").whereEqualTo("clientID",sharedPrefManager.getUserID() ).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if (!queryDocumentSnapshots.isEmpty()) {
                    queryDocumentSnapshots.getDocuments().forEach(documentSnapshot -> {

                        ProductModel tempProductModel= documentSnapshot.toObject(ProductModel.class);
                        productModelList.add(tempProductModel);

                    });
                }
                myAdapter = new MyAdapter(ActivityCart.this,3,productModelList);
                binding.rvProducts.setAdapter(myAdapter);
                myAdapter.notifyDataSetChanged();



            }
        });


    }


    @Override
    public void onItemClick(ProductModel productItem) {


        Toast.makeText(this, "debug1", Toast.LENGTH_SHORT).show();

       /* Bundle bundle = new Bundle();
        bundle.putParcelable("productItem", productItem);

        NavController navController = Navigation.findNavController(ActivityCart.this, R.id.nav_host_fragment_activity_bottom_navigation_menu);
        navController.navigate(R.id.action_navigation_dashboard_to_productDetailsFragment, bundle);*/
    }

    @Override
    public void onCartClick(ProductModel productItem) {

    }

    @Override
    public void onStatusClick(ProductModel productItem) {

    }

    @Override
    public void onDeleteClick(int position, ProductModel productItem) {

        deleteProduct(position,productItem);
    }
}