package com.example.exsell;

import android.content.Context;
import android.content.SharedPreferences;


public class SharedPrefManager {
    public static String SHARED_PREF_NAME = "excell";
    private SharedPreferences sharedPreferences;
    private Context context;
    private SharedPreferences.Editor editor;
    final String PREF_PROFILE_LINK = "profilelink";

    public SharedPrefManager(Context context) {
        this.context = context;
    }

    public SharedPrefManager() {

    }


    public void saveUser(UserModel user) {
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.putString("userFirstName", user.getUserFirstName());
        editor.putString("userAccountCreationDate", user.getDateOfAccountCreation());
        editor.putString("userLastName", user.getUserLastName());
        editor.apply();
    }

    public void setUserID(String userID) {
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.putString("userID", userID);
        editor.apply();
    }

    public String getUserID(){
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);

        return sharedPreferences.getString("userID", "");
    }

    public void loggedIn(Boolean loggedIn) {
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.putBoolean("logged", true);
        editor.apply();
    }


    public boolean isLoggedIn() {
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean("logged", false);
    }

    public UserModel getUser() {
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new UserModel(
                sharedPreferences.getString("userFirstName", null),
                sharedPreferences.getString("userLastName", null),
                sharedPreferences.getString("userAccountCreationDate", null)

        );

    }


    public void logout() {
        sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }
}
