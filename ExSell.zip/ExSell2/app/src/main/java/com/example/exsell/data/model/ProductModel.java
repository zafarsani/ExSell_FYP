package com.example.exsell.data.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class ProductModel implements Parcelable {

    public ProductModel(){

    }

    String clientID;
    String DocID;
    String productName;
    String productPrice;
    String productQuantity;
    String productDescription;
    String city, ctg,subCtg,phone,status;


    String  userID,image1,image2,image3,image4,image5,image6;


    public ProductModel(String docID, String productName, String productPrice, String productQuantity, String productDescription, String city, String ctg, String subCtg, String phone, String status, String userID, String image1, String image2, String image3, String image4, String image5, String image6) {
        DocID = docID;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
        this.productDescription = productDescription;
        this.city = city;
        this.ctg = ctg;
        this.subCtg = subCtg;
        this.phone = phone;
        this.status = status;
        this.userID = userID;
        this.image1 = image1;
        this.image2 = image2;
        this.image3 = image3;
        this.image4 = image4;
        this.image5 = image5;
        this.image6 = image6;
    }

    public ProductModel(String productName, String productPrice, String productQuantity, String productDescription, String city, String ctg, String subCtg, String phone, String status, String userID, String image1, String image2, String image3, String image4, String image5, String image6) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
        this.productDescription = productDescription;
        this.city = city;
        this.ctg = ctg;
        this.subCtg = subCtg;
        this.phone = phone;
        this.status = status;
        this.userID = userID;
        this.image1 = image1;
        this.image2 = image2;
        this.image3 = image3;
        this.image4 = image4;
        this.image5 = image5;
        this.image6 = image6;
    }

    public ProductModel(String productName, String productPrice, String productQuantity, String productDescription, String city, String ctg, String subCtg, String phone, String status, String userID, String image1, String image2, String image3) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
        this.productDescription = productDescription;
        this.city = city;
        this.ctg = ctg;
        this.subCtg = subCtg;
        this.phone = phone;
        this.status = status;
        this.userID = userID;
        this.image1 = image1;
        this.image2 = image2;
        this.image3 = image3;
    }

    public ProductModel(String productName, String productPrice, String productQuantity, String productDescription, String citiy, String ctg, String subCtg, String phone, String userID, String image1, String image2, String image3) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
        this.productDescription = productDescription;
        this.city = citiy;
        this.ctg = ctg;
        this.subCtg = subCtg;
        this.phone = phone;
        this.userID = userID;
        this.image1 = image1;
        this.image2 = image2;
        this.image3 = image3;
    }



    public ProductModel(String productName, String productPrice, String productQuantity, String productDescription, String userID, String image1, String image2, String image3) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
        this.productDescription = productDescription;
        this.userID = userID;
        this.image1 = image1;
        this.image2 = image2;
        this.image3 = image3;
    }




    protected ProductModel(Parcel in) {
        productName = in.readString();
        productPrice = in.readString();
        productQuantity = in.readString();
        productDescription = in.readString();
        userID = in.readString();
        image1 = in.readString();
        image2 = in.readString();
        image3 = in.readString();
    }


    public String getClientID() {
        return clientID;
    }

    public void setClientID(String clientID) {
        this.clientID = clientID;
    }

    public String getDocID() {
        return DocID;
    }

    public void setDocID(String docID) {
        DocID = docID;
    }

    public String getImage4() {
        return image4;
    }

    public void setImage4(String image4) {
        this.image4 = image4;
    }

    public String getImage5() {
        return image5;
    }

    public void setImage5(String image5) {
        this.image5 = image5;
    }

    public String getImage6() {
        return image6;
    }

    public void setImage6(String image6) {
        this.image6 = image6;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCtg() {
        return ctg;
    }

    public void setCtg(String ctg) {
        this.ctg = ctg;
    }

    public String getSubCtg() {
        return subCtg;
    }

    public void setSubCtg(String subCtg) {
        this.subCtg = subCtg;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public static final Creator<ProductModel> CREATOR = new Creator<ProductModel>() {
        @Override
        public ProductModel createFromParcel(Parcel in) {
            return new ProductModel(in);
        }

        @Override
        public ProductModel[] newArray(int size) {
            return new ProductModel[size];
        }
    };

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }



    public String getImage1() {
        return image1;
    }

    public void setImage1(String image1) {
        this.image1 = image1;
    }

    public String getImage2() {
        return image2;
    }

    public void setImage2(String image2) {
        this.image2 = image2;
    }

    public String getImage3() {
        return image3;
    }

    public void setImage3(String image3) {
        this.image3 = image3;
    }



    public ProductModel(String productName, String productPrice, String productQuantity, String productDescription, String image1, String image2, String image3) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
        this.productDescription = productDescription;
        this.image1 = image1;
        this.image2 = image2;
        this.image3 = image3;
    }


    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(String productQuantity) {
        this.productQuantity = productQuantity;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {

        parcel.writeString(productDescription);
        parcel.writeString(productName);
        parcel.writeString(productPrice);
        parcel.writeString(productQuantity);
        parcel.writeString(userID);
        parcel.writeString(image1);
        parcel.writeString(image2);
        parcel.writeString(image3);

    }
}
