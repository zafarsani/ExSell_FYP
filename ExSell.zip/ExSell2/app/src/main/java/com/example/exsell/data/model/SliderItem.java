package com.example.exsell.data.model;

import android.net.Uri;

public class SliderItem {

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public SliderItem(String image) {
        this.image = image;
    }

    private String image;


}
