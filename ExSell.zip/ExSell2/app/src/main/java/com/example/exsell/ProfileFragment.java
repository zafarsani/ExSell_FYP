package com.example.exsell;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;
import com.example.exsell.databinding.FragmentProfileBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.Objects;

public class ProfileFragment extends Fragment {


    private FragmentProfileBinding binding;

    String photoURI = "";

    FirebaseStorage storage;

    StorageReference storageReference;

    FirebaseFirestore firebaseFirestore;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;

    private SharedPrefManager sharedPrefManager;





    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(getLayoutInflater(), container, false);
        // Inflate the layout for this fragment

        sharedPrefManager  = new SharedPrefManager(getActivity());

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseFirestore = FirebaseFirestore.getInstance();

        storage = FirebaseStorage.getInstance();

        //storageReference = storage.getReference().child(firebaseUser.getUid());
        storageReference = storage.getReference().child(sharedPrefManager.getUserID());

        binding.btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sharedPrefManager.logout();
                startActivity(new Intent(getActivity(), Login.class));
                Objects.requireNonNull(getActivity()).finish();

            }
        });



        firebaseFirestore.collection("UsersDetails").document(sharedPrefManager.getUserID()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {

              /*  UserModel userModel = new UserModel();

                userModel = documentSnapshot.toObject(UserModel.class);*/

                String firstName = documentSnapshot.getString("userFirstName");
                String lastName = documentSnapshot.getString("userLastName");
                String password = documentSnapshot.getString("password");
                String email = documentSnapshot.getString("emailAddress");
                String profileURI = documentSnapshot.getString("profilePhoto");
                String accountCreationDate = documentSnapshot.getString("dateOfAccountCreation");


                binding.etUserfname.setText(firstName);
                binding.etuserlname.setText(lastName);

                binding.tvDateOfAccountCreation.setText("Member since " +accountCreationDate);
               // binding.etpassword.setText(password);
              //  binding.etemail.setText(email);

                if (profileURI != null) {
                    Glide.with(requireActivity())
                            .load(profileURI)
                            .into(binding.ivProfilePic);

                    //  binding.ivProfilePic.setImageURI(Uri.parse(profileURI));
                }
            }
        });


        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), EditProfileActivity.class));
            }
        });


        return binding.getRoot();
    }
}