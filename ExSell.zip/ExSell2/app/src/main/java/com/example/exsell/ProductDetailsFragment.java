package com.example.exsell;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.exsell.data.model.ProductModel;
import com.example.exsell.data.model.SliderItem;
import com.example.exsell.databinding.FragmentProductDetailsBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class ProductDetailsFragment extends Fragment {

    private FragmentProductDetailsBinding binding;

    private Handler sliderHandler = new Handler();

    private FirebaseFirestore firebaseFirestore;

    private String WA;

    public ProductDetailsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        binding = FragmentProductDetailsBinding.inflate(getLayoutInflater(), container, false);
        firebaseFirestore = FirebaseFirestore.getInstance();


        assert getArguments() != null;
        ProductModel productModel = getArguments().getParcelable("productItem");


        binding.productName.setText(productModel.getProductName());
        binding.productPrice.setText(productModel.getProductPrice());
        binding.productDescription.setText(productModel.getProductDescription());
        binding.productQuantity.setText(productModel.getProductQuantity());
        WA= productModel.getPhone();

        binding.phoneNumber.setText(productModel.getPhone());
        binding.tvCtg.setText(productModel.getCtg());
        binding.userLocation.setText(productModel.getCity());
        binding.btnChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                contactDialog(WA,WA,WA);

            }
        });

        //Glide.with(requireContext()).load(productModel.getImage1()).into(binding.imageLarge);


        firebaseFirestore.collection("UsersDetails").document(productModel.getUserID()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {

                String userName = documentSnapshot.getString("userFirstName") + documentSnapshot.getString("userLastName");
                String userDateOfAccountCreation = documentSnapshot.getString("dateOfAccountCreation");

                binding.sellerName.setText(userName);
                binding.userJoiningDate.setText(userDateOfAccountCreation);

            }
        });


        setSlider(productModel);


        return binding.getRoot();
    }

    private Runnable SliderRunnable = new Runnable() {
        @Override
        public void run() {
            binding.viewPager.setCurrentItem(binding.viewPager.getCurrentItem() + 1);


        }
    };




    private void contactDialog(String WA, String Call,String Msg){

        final Dialog dialog = new Dialog(getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog_contact);

        LinearLayout layMsg = (LinearLayout) dialog.findViewById(R.id.layMsg);
        LinearLayout layWA = (LinearLayout) dialog.findViewById(R.id.layWA);
        LinearLayout layCall = (LinearLayout) dialog.findViewById(R.id.layCall);
        ImageView imgClose = (ImageView) dialog.findViewById(R.id.imgClose);

        layMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sendIntent = new Intent(Intent.ACTION_VIEW);
                sendIntent.setData(Uri.parse("sms:"+Msg));
                startActivity(sendIntent);

            }
        });

        layWA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("smsto:" + WA);
                Intent i = new Intent(Intent.ACTION_SENDTO, uri);
                i.setPackage("com.whatsapp");
                startActivity(Intent.createChooser(i, ""));
            }
        });

        layCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+Call));
                startActivity(intent);
            }
        });

        imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();
            }
        });
        dialog.show();

    }


    public void setSlider(ProductModel productModel) {
        List<SliderItem> sliderItemList = new ArrayList<>();
        sliderItemList.add(new SliderItem(productModel.getImage1()));
        sliderItemList.add(new SliderItem(productModel.getImage2()));
        sliderItemList.add(new SliderItem(productModel.getImage3()));
        sliderItemList.add(new SliderItem(productModel.getImage4()));
        sliderItemList.add(new SliderItem(productModel.getImage5()));
        sliderItemList.add(new SliderItem(productModel.getImage6()));

        binding.viewPager.setAdapter(new ProductSliderAdapter(sliderItemList, binding.viewPager, requireContext()));
        binding.viewPager.setClipToPadding(false);
        binding.viewPager.setClipChildren(false);
        binding.viewPager.setOffscreenPageLimit(6);
        binding.viewPager.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);
        binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                sliderHandler.removeCallbacks(SliderRunnable);
                sliderHandler.postDelayed(SliderRunnable, 3000);
            }
        });
    }
}