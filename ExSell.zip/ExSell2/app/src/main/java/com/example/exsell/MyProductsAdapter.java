package com.example.exsell;


import android.content.Context;
import android.content.Intent;
import android.os.Debug;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.exsell.data.model.ProductModel;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class MyProductsAdapter extends RecyclerView.Adapter<MyProductsAdapter.ViewHolder> implements View.OnClickListener  {
    private List<ProductModel> data;

    private FirebaseFirestore firebaseFirestore;

    private ProductModel item;

    public interface OnAdapterIntractionListner {
        void onItemClick(ProductModel productItem);
        void onCartClick(ProductModel productItem);
        void onStatusChange(ProductModel productItem);
    }
    public OnAdapterIntractionListner onAdapterIntractionListner;

    Context context;
    public MyProductsAdapter(Context context,List<ProductModel> data) {
        firebaseFirestore = FirebaseFirestore.getInstance();
        this.data = data;
        this.context=context;
    }

    public OnAdapterIntractionListner getOnAdapterIntractionListner() {
        return onAdapterIntractionListner;
    }

    public void setOnAdapterIntractionListner(OnAdapterIntractionListner onAdapterIntractionListner) {
        this.onAdapterIntractionListner = onAdapterIntractionListner;
    }

    @Override
    public void onClick(View v) {

    }





    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.product_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {


         item = data.get(position);

        holder.titleTextView.setText(item.getProductPrice());
        holder.descriptionTextView.setText(item.getProductName());
        holder.userLocation.setText(item.getCity());
        holder.tvCTG.setText(item.getCtg());
        if(item.getStatus().equals("Available")) holder.switchStatus.setChecked(true);
        else holder.switchStatus.setChecked(false);

        Glide.with(holder.itemView.getContext()).load(item.getImage1()).into(holder.imageView);




        holder.imgCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        holder.switchStatus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked==true){
                    item.setStatus("Available");
                    onAdapterIntractionListner.onStatusChange(item);
                    /*firebaseFirestore.collection("Products").document(item.getDocID()).set(item)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {

                                    Toast.makeText(context, "Status Updated", Toast.LENGTH_SHORT).show();
                                }
                            });*/
                }
                else {

                    item.setStatus("NA");
                    onAdapterIntractionListner.onStatusChange(item);
                    /*firebaseFirestore.collection("Products").document(item.getDocID()).set(item)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {

                                    Toast.makeText(context, "Status Updated", Toast.LENGTH_SHORT).show();
                                }
                            });*/

                }

            }
        });
    }

    @Override
    public int getItemCount() {

        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView titleTextView,tvCTG;
        public TextView descriptionTextView;
        public TextView userLocation;
        public ImageView imageView,imgCart;

        public Switch switchStatus;
        public ViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.tvPrice);
            tvCTG = itemView.findViewById(R.id.tvCTG);
            descriptionTextView = itemView.findViewById(R.id.tvTitle);
            imageView = itemView.findViewById(R.id.imageProduct);
            imgCart = itemView.findViewById(R.id.imgCart);
            userLocation = itemView.findViewById(R.id.tvUserLocation);
            switchStatus = itemView.findViewById(R.id.switchStatus);
            imgCart.setVisibility(View.GONE);





        }

        @Override
        public void onClick(View v) {

        }
    }

}