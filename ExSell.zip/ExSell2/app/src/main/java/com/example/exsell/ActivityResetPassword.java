package com.example.exsell;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.exsell.data.model.ProductModel;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.auth.User;

public class ActivityResetPassword extends AppCompatActivity {


    private FirebaseAuth firebaseAuth;

    private SharedPrefManager sharedPrefManager;
    FirebaseFirestore firebaseFirestore;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);
        EditText etPassword= findViewById(R.id.etpassword);
        EditText etCnfrmpassword= findViewById(R.id.etCnfrmpassword);
        Button btnSetPass= findViewById(R.id.btnSetPass);
        firebaseFirestore = FirebaseFirestore.getInstance();

        btnSetPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!etPassword.getText().toString().equals(etCnfrmpassword.getText().toString()))
                {
                    Toast.makeText(ActivityResetPassword.this, "Password not matched", Toast.LENGTH_SHORT).show();
                }
                else setPassword(getIntent().getStringExtra("email"),etPassword.getText().toString());
            }
        });


    }

    private void setPassword(String email, String password) {

        firebaseFirestore.collection("UsersDetails")
                .whereEqualTo("emailAddress",email).get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        if (!queryDocumentSnapshots.isEmpty()) {
                            queryDocumentSnapshots.getDocuments().forEach(documentSnapshot -> {

                                Toast.makeText(ActivityResetPassword.this, documentSnapshot.getId(), Toast.LENGTH_SHORT).show();
                                UserModel userModel= documentSnapshot.toObject(UserModel.class);


                                userModel.setPassword(password);
                                firebaseFirestore.collection("UsersDetails")
                                        .document(documentSnapshot.getId())
                                        .update("password",password)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void unused) {
                                                Intent intent = new Intent(ActivityResetPassword.this, Login.class);
                                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                startActivity(intent);
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(ActivityResetPassword.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        });


                            });
                        }

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(ActivityResetPassword.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


    }
}