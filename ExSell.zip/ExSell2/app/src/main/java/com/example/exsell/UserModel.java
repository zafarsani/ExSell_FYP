package com.example.exsell;

public class UserModel {
    String UserFirstName;
    String UserLastName;
    String Password;

    String EmailAddress;
    String DateOfAccountCreation;

    String profilePhoto;


    String userID;
    String City;
    String UserLocation;

    public UserModel(String firstName, String lastName, String email, String uid, String uri, String city, String location) {
        this.UserFirstName = firstName;
        this.UserLastName = lastName;
        this.EmailAddress = email;
        this.userID = uid;
        this.profilePhoto = uri;
        this.City = city;
        this.UserLocation = location;
    }

    public UserModel(String userFirstName, String userLastName, String password, String email, String userID, String dateOfAccountCreation) {
        this.UserFirstName = userFirstName;
        this.UserLastName = userLastName;
        this.Password = password;
        this.EmailAddress = email;
        this.userID = userID;
        this.DateOfAccountCreation = dateOfAccountCreation;
    }

    public UserModel(String userFirstName, String userLastName, String dateOfAccountCreation) {
        this.UserFirstName = userFirstName;
        this.UserLastName = userLastName;
        this.DateOfAccountCreation = dateOfAccountCreation;
    }


    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getUserLocation() {
        return UserLocation;
    }

    public void setUserLocation(String userLocation) {
        UserLocation = userLocation;
    }


    public String getDateOfAccountCreation() {
        return DateOfAccountCreation;
    }

    public void setDateOfAccountCreation(String dateOfAccountCreation) {
        DateOfAccountCreation = dateOfAccountCreation;
    }


    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }



    public String getProfilePhoto() {
        return profilePhoto;
    }

    public void setProfilePhoto(String profilePhoto) {
        this.profilePhoto = profilePhoto;
    }




    public UserModel() {

    }


    public String getUserFirstName() {
        return UserFirstName;
    }

    public void setUserFirstName(String userFirstName) {
        UserFirstName = userFirstName;
    }

    public String getUserLastName() {
        return UserLastName;
    }

    public void setUserLastName(String userLastName) {
        UserLastName = userLastName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getEmailAddress() {
        return EmailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        EmailAddress = emailAddress;
    }
}
