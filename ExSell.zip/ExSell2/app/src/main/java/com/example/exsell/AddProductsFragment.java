package com.example.exsell;

import static android.app.Activity.RESULT_OK;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.example.exsell.data.model.ProductModel;
import com.example.exsell.databinding.FragmentAddProductsBinding;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AddProductsFragment extends Fragment {

    ProgressDialog progressDialog;




    private FragmentAddProductsBinding binding;
    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;

    private StorageReference storageReference;
    private FirebaseStorage firebaseStorage;

    private ProductModel productModel;

    int productQuantity = 0;

    private FirebaseFirestore firebaseFirestore;

    private Uri image1;
    private Uri image2;
    private Uri image3,image4,image5,image6;
    private static final int REQUEST_IMAGE_CAPTURE = 1;


    ArrayAdapter<String> adapterCities, adapterCtg, adapterSubCtg;
    List<String> listCities, listCtg, listElectronics, listClothing, listFurniture, listGroceries, listHealthProducts;




    public AddProductsFragment() {
        // Required empty public constructor
    }





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAddProductsBinding.inflate(getLayoutInflater(), container, false);
        // Inflate the layout for this fragment


        progressDialog = new ProgressDialog(getContext());

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();


        listCities= new ArrayList<String>();
        listCtg= new ArrayList<String>();





        listCtg= new ArrayList<String>();
        listElectronics= new ArrayList<String>();
        listClothing= new ArrayList<String>();
        listFurniture= new ArrayList<String>();
        listGroceries= new ArrayList<String>();
        listHealthProducts= new ArrayList<String>();


        productModel = new ProductModel();

        binding.ivImage1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                dispatchTakePictureIntent(1);
            }
        });
        binding.ivImage2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dispatchTakePictureIntent(2);
            }
        });

        binding.ivImage3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dispatchTakePictureIntent(3);
            }
        });
        binding.ivImage4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dispatchTakePictureIntent(4);
            }
        });
        binding.ivImage5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dispatchTakePictureIntent(5);
            }
        });
        binding.ivImage6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dispatchTakePictureIntent(6);
            }
        });

        setData();

        return binding.getRoot();
    }

    private void dispatchTakePictureIntent(int imageNum) {



        Intent getIntent = new Intent(Intent.ACTION_GET_CONTENT);
        getIntent.setType("image/*");
        Intent pickIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");
        Intent chooserIntent = Intent.createChooser(getIntent, "Select Image");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] {pickIntent});
        startActivityForResult(chooserIntent, imageNum);


        //Toast.makeText(AddProductsFragment.this, "debug1", Toast.LENGTH_SHORT).show();

        /*Toast.makeText(getContext(), "debug1", Toast.LENGTH_SHORT).show();

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        takePictureIntent.setType("image/*");
        Intent pickIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");
        Intent chooserIntent = Intent.createChooser(takePictureIntent,"Select Image");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{pickIntent});

        startActivityForResult(chooserIntent, 1);*/




        /*if (takePictureIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivityForResult(chooserIntent, imageNum);
        }*/
    }



    public void setData(){

        /////////////////////// Cities ////////////////////
        listCities.add("Karachi");
        listCities.add("Lahore");
        listCities.add("Islamabad");
        listCities.add("Rawalpindi");
        listCities.add("Faisalabad");
        listCities.add("Multan");
        listCities.add("Hyderabad");
        listCities.add("Gujranwala");
        listCities.add("Peshawar");
        listCities.add("Quetta");
        listCities.add("Sargodha");
        listCities.add("Sialkot");
        listCities.add("Bahawalpur");
        listCities.add("Sukkur");
        listCities.add("Abbottabad");
        listCities.add("Gujrat");
        listCities.add("Jhang");
        listCities.add("Rahim Yar Khan");
        listCities.add("Larkana");
        listCities.add("Sheikhupura");
        ///////////////////////////////////////////////


        /////////////////////// CTG ////////////////////

        listCtg.add("Electronics");
        listCtg.add("Clothing");
        listCtg.add("Furniture");
        listCtg.add("Groceries Items");
        listCtg.add("Health Products");
        ////////////////////////////////////////////////////





        adapterCities= new ArrayAdapter<String>(getActivity(),R.layout.item_spiner,listCities);
        binding.spnCities.setAdapter(adapterCities);

        adapterCtg= new ArrayAdapter<String>(getActivity(),R.layout.item_spiner,listCtg);
        binding.spnCtg.setAdapter(adapterCtg);


        /////////////////////// SUB-CTG Electronics ////////////////////

        listElectronics.add("Televisions");
        listElectronics.add("Computers and Laptops");
        listElectronics.add("Mobile Phones and Accessories");
        listElectronics.add("Audio and Video Equipment");
        listElectronics.add("Cameras and Photography Equipment");
        listElectronics.add("Home Theater Systems");
        listElectronics.add("Gaming Consoles and Accessories");
        listElectronics.add("Smart Home Devices");
        listElectronics.add("Wearable Technology");
        listElectronics.add("Computer Components and Parts");
        listElectronics.add("Printers and Scanners");
        listElectronics.add("Networking Devices");
        listElectronics.add("Power Banks and Chargers");
        listElectronics.add("Headphones and Earphones");
        listElectronics.add("Speakers");
        listElectronics.add("GPS and Navigation Devices");
        listElectronics.add("Home Appliances");
        listElectronics.add("Electronic Gadgets and Gizmos");
        listElectronics.add("Electronic Accessories");
        listElectronics.add("Virtual Reality (VR) Devices");
        ////////////////////////////////////////////////////////////////////////////////



        /////////////////////// SUB-CTG Clothing ////////////////////

        listClothing.add("T-shirts");
        listClothing.add("Dresses");
        listClothing.add("Jeans");
        listClothing.add("Shirts");
        listClothing.add("Tops");
        listClothing.add("Skirts");
        listClothing.add("Suits");
        listClothing.add("Sweaters");
        listClothing.add("Coats and Jackets");
        listClothing.add("Pants and Trousers");
        listClothing.add("Shorts");
        listClothing.add("Underwear");
        listClothing.add("Socks");
        listClothing.add("Swimwear");
        listClothing.add("Sportswear");
        listClothing.add("Sleepwear");
        listClothing.add("Ethnic Wear");
        listClothing.add("Kids' Clothing");
        listClothing.add("Maternity Clothing");
        ////////////////////////////////////////////////////////////////////////////////


        /////////////////////// SUB-CTG Furniture ////////////////////

        listFurniture.add("Sofas");
        listFurniture.add("Chairs");
        listFurniture.add("Tables");
        listFurniture.add("Beds");
        listFurniture.add("Cabinets");
        listFurniture.add("Dressers");
        listFurniture.add("Desks");
        listFurniture.add("Shelves");
        listFurniture.add("TV Stands");
        listFurniture.add("Dining Sets");
        listFurniture.add("Wardrobes");
        listFurniture.add("Bookcases");
        listFurniture.add("Coffee Tables");
        listFurniture.add("Side Tables");
        listFurniture.add("Ottomans");
        listFurniture.add("Benches");
        listFurniture.add("Stools");
        listFurniture.add("Bar Furniture");
        listFurniture.add("Outdoor Furniture");
        listFurniture.add("Baby Furniture");
        ////////////////////////////////////////////////////////////////////////////////

        /////////////////////// SUB-CTG Groceries ////////////////////

        listGroceries.add("Bakery");
        listGroceries.add("Dairy and Eggs");
        listGroceries.add("Fresh Produce");
        listGroceries.add("Meat and Poultry");
        listGroceries.add("Seafood");
        listGroceries.add("Canned Goods");
        listGroceries.add("Dry Goods");
        listGroceries.add("Frozen Foods");
        listGroceries.add("Snacks and Sweets");
        listGroceries.add("Beverages");
        listGroceries.add("Condiments and Sauces");
        listGroceries.add("Spices and Seasonings");
        listGroceries.add("Pasta and Rice");
        listGroceries.add("Bread and Baked Goods");
        listGroceries.add("Breakfast Foods");
        listGroceries.add("Baby Food and Formula");
        listGroceries.add("Health and Wellness");
        listGroceries.add("Pet Food and Supplies");
        listGroceries.add("Cleaning and Household");
        listGroceries.add("Paper Products");
        ////////////////////////////////////////////////////////////////////////////////


        /////////////////////// SUB-CTG Health Products ////////////////////

        listHealthProducts.add("Vitamins and Supplements");
        listHealthProducts.add("Medications");
        listHealthProducts.add("Personal Care");
        listHealthProducts.add("First Aid");
        listHealthProducts.add("Hygiene Products");
        listHealthProducts.add("Beauty and Skincare");
        listHealthProducts.add("Fitness and Exercise");
        listHealthProducts.add("Weight Management");
        listHealthProducts.add("Home Health Monitors");
        listHealthProducts.add("Natural and Herbal Remedies");
        listHealthProducts.add("Medical Equipment");
        listHealthProducts.add("Mobility Aids");
        listHealthProducts.add("Orthopedic Supports");
        listHealthProducts.add("Pain Relief");
        listHealthProducts.add("Dietary and Nutrition");
        listHealthProducts.add("Digestive Health");
        listHealthProducts.add("Eye Care");
        listHealthProducts.add("Oral Care");
        listHealthProducts.add("Hair Care");





        binding.spnCtg.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if(position==0) adapterSubCtg= new ArrayAdapter<>(getActivity(),R.layout.item_spiner,listElectronics);
                else if(position==1) adapterSubCtg= new ArrayAdapter<>(getActivity(),R.layout.item_spiner,listClothing);
                else if(position==2) adapterSubCtg= new ArrayAdapter<>(getActivity(),R.layout.item_spiner,listFurniture);
                else if(position==3) adapterSubCtg= new ArrayAdapter<>(getActivity(),R.layout.item_spiner,listGroceries);
                else if(position==4) adapterSubCtg= new ArrayAdapter<>(getActivity(),R.layout.item_spiner,listHealthProducts);

                binding.spnSubCtg.setAdapter(adapterSubCtg);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {


            }
        });










    }

    public void addProduct() {
        
        progressDialog.show();
        firebaseFirestore.collection("Products").add(productModel).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), "Product Added", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getActivity(),MainActivity.class));
                getActivity().finish();
            }
        });

    }


    public void getProductDetails() {


        String productName = binding.etProductName.getText().toString();
        String productPrice = binding.etProductPrice.getText().toString();
        String productQuantity = binding.etProductQuantity.getText().toString();
        String productDescription = binding.etProductDescription.getText().toString();



        productModel.setPhone(binding.etPhone.getText().toString());
        productModel.setCity(binding.spnCities.getSelectedItem().toString());
        productModel.setCtg(binding.spnCtg.getSelectedItem().toString());
        productModel.setSubCtg(binding.spnSubCtg.getSelectedItem().toString());
        productModel.setStatus("Available");

        productModel.setProductName(productName);
        productModel.setProductDescription(productDescription);
        productModel.setProductPrice(productPrice);
        productModel.setProductQuantity(productQuantity);
        productModel.setUserID(firebaseUser.getUid());

        if (image1 != null) productModel.setImage1(image1.toString());
        if (image2 != null) productModel.setImage2(image2.toString());
        if (image3 != null) productModel.setImage3(image3.toString());
        if (image4 != null) productModel.setImage4(image4.toString());
        if (image5 != null) productModel.setImage5(image5.toString());
        if (image6 != null) productModel.setImage6(image6.toString());


    }





    ////////********************////////////

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK) {
            return;
        }
        else {
            Uri uri = data.getData();
            if(requestCode == 1){
                //Glide.with(AddProductsFragment.this).load(new File(uri.getPath())).into(binding.ivImage1);

                try {
                    final InputStream imageStream;
                    imageStream = getActivity().getContentResolver().openInputStream(uri);

                    final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    Glide.with(AddProductsFragment.this).load(selectedImage) // Uri of the picture
                            .into(binding.ivImage1);

                    saveImageToFirebaseAndGetUri(selectedImage, 1);



                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }

            }
            else if(requestCode == 2){
                //Glide.with(AddProductsFragment.this).load(new File(uri.getPath())).into(binding.ivImage1);

                try {
                    final InputStream imageStream;
                    imageStream = getActivity().getContentResolver().openInputStream(uri);

                    final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    Glide.with(AddProductsFragment.this).load(selectedImage) // Uri of the picture
                            .into(binding.ivImage2);

                    saveImageToFirebaseAndGetUri(selectedImage, 2);



                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }

            }
            else if(requestCode == 3){
                //Glide.with(AddProductsFragment.this).load(new File(uri.getPath())).into(binding.ivImage1);

                try {
                    final InputStream imageStream;
                    imageStream = getActivity().getContentResolver().openInputStream(uri);

                    final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    Glide.with(AddProductsFragment.this).load(selectedImage) // Uri of the picture
                            .into(binding.ivImage3);

                    saveImageToFirebaseAndGetUri(selectedImage, 3);

                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }

            }
            else if(requestCode == 4){
                //Glide.with(AddProductsFragment.this).load(new File(uri.getPath())).into(binding.ivImage1);

                try {
                    final InputStream imageStream;
                    imageStream = getActivity().getContentResolver().openInputStream(uri);

                    final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    Glide.with(AddProductsFragment.this).load(selectedImage) // Uri of the picture
                            .into(binding.ivImage4);

                    saveImageToFirebaseAndGetUri(selectedImage, 4);

                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }

            }
            else if(requestCode == 5){
                //Glide.with(AddProductsFragment.this).load(new File(uri.getPath())).into(binding.ivImage1);

                try {
                    final InputStream imageStream;
                    imageStream = getActivity().getContentResolver().openInputStream(uri);

                    final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    Glide.with(AddProductsFragment.this).load(selectedImage) // Uri of the picture
                            .into(binding.ivImage5);

                    saveImageToFirebaseAndGetUri(selectedImage, 5);

                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }

            }
            else if(requestCode == 6){
                //Glide.with(AddProductsFragment.this).load(new File(uri.getPath())).into(binding.ivImage1);

                try {
                    final InputStream imageStream;
                    imageStream = getActivity().getContentResolver().openInputStream(uri);

                    final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                    Glide.with(AddProductsFragment.this).load(selectedImage) // Uri of the picture
                            .into(binding.ivImage6);

                    saveImageToFirebaseAndGetUri(selectedImage, 6);

                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }

            }

        }


       /* else if (requestCode == PICK_IMAGE) {
            Uri uri = data.getData();
            if (requestCode == 1){

                Glide.with(AddProductsFragment.this).load(new File(uri.getPath())) // Uri of the picture
                        .into(binding.ivImage1);
                saveImageToFirebaseAndGetUri(imageBitmap, 1);

            }




            try {
                final InputStream imageStream;
                imageStream = getContentResolver().openInputStream(uri);

                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                Glide.with(context).load(selectedImage) // Uri of the picture
                        .into(binding.imgCar);
                //String encodedImage = encodeImage(uri.getPath());
                encodedImage = encodeImage(selectedImage);


            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }

        }



        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                Bundle extras = data.getExtras();
                Bitmap imageBitmap = (Bitmap) extras.get("data");
                binding.ivImage1.setImageBitmap(imageBitmap);
                saveImageToFirebaseAndGetUri(imageBitmap, 1);
            } else if (requestCode == 2) {
                Bundle extras = data.getExtras();
                Bitmap imageBitmap = (Bitmap) extras.get("data");
                binding.ivImage2.setImageBitmap(imageBitmap);
                saveImageToFirebaseAndGetUri(imageBitmap, 2);
            } else if (requestCode == 3) {
                Bundle extras = data.getExtras();
                Bitmap imageBitmap = (Bitmap) extras.get("data");
                binding.ivImage3.setImageBitmap(imageBitmap);
                saveImageToFirebaseAndGetUri(imageBitmap, 3);
            }
        }*/

    }


    private Task<Uri> saveImageToFirebaseAndGetUri(Bitmap bitmap, int imageNum) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        String timestamp = String.valueOf(System.currentTimeMillis());
        StorageReference imageRef = storageReference.child("productImages" + timestamp + ".jpg");
        UploadTask uploadTask = imageRef.putBytes(data);

        return uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if (!task.isSuccessful()) {
                    throw Objects.requireNonNull(task.getException());
                }

                return imageRef.getDownloadUrl();
            }
        }).addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                switch (imageNum) {
                    case 1:
                        image1 = uri;
                        break;
                    case 2:
                        image2 = uri;
                        break;
                    case 3:
                        image3 = uri;
                        break;
                    case 4:
                        image4 = uri;
                        break;
                    case 5:
                        image5 = uri;
                        break;
                    case 6:
                        image6 = uri;
                        break;
                }

                binding.btnSubmit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getProductDetails();
                        addProduct();
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Log.e("Firebase Storage", "Error uploading image: " + exception.getMessage());
            }
        });
    }

    void startLoading(){

    }


}