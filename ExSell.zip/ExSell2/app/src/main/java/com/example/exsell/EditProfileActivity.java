package com.example.exsell;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.exsell.databinding.ActivityEditProfileBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class EditProfileActivity extends AppCompatActivity {

    ActivityEditProfileBinding binding;
    StorageReference storageReference;

    String photoURI = "";

    FirebaseStorage storage;

    private SharedPrefManager sharedPrefManager;

    FirebaseFirestore firebaseFirestore;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;

    CircleImageView civProfileUpload;
    private static final int PICK_IMAGE_REQUEST = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEditProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        sharedPrefManager  = new SharedPrefManager(EditProfileActivity.this);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseFirestore = FirebaseFirestore.getInstance();
        civProfileUpload = findViewById(R.id.ivProfilePic);

        
        storage = FirebaseStorage.getInstance();

        storageReference = storage.getReference().child(sharedPrefManager.getUserID());


        civProfileUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);


            }
        });


        //   Toast.makeText(this, sharedPrefManager.getUserID().toString(), Toast.LENGTH_SHORT).show();

        firebaseFirestore.collection("UsersDetails").document(sharedPrefManager.getUserID()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {

              /*  UserModel userModel = new UserModel();

                userModel = documentSnapshot.toObject(UserModel.class);*/

                String firstName = documentSnapshot.getString("userFirstName");
                String lastName = documentSnapshot.getString("userLastName");
                String password = documentSnapshot.getString("password");
                String email = documentSnapshot.getString("emailAddress");
                String profileURI = documentSnapshot.getString("profilePhoto");
                String location = documentSnapshot.getString("userLocation");
                String city = documentSnapshot.getString("city");


                binding.etUserfname.setText(firstName);
                binding.etuserlname.setText(lastName);
                binding.etLocation.setText(location);
                binding.etCity.setText(city);
                binding.etemail.setText(email);

                if (profileURI != null) {
                    Glide.with(EditProfileActivity.this)
                            .load(profileURI)
                            .into(binding.ivProfilePic);

                    //  binding.ivProfilePic.setImageURI(Uri.parse(profileURI));
                }
            }
        });


        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (photoURI.isEmpty()) {
                    Toast.makeText(EditProfileActivity.this, "Wait photo is uploading", Toast.LENGTH_SHORT).show();
                } else {
                    userUpdate(photoURI);
                }
            }
        });


    }

    public void userUpdate(String uri) {

        String firstName = binding.etUserfname.getText().toString();
        String lastName = binding.etuserlname.getText().toString();
        String city = binding.etCity.getText().toString();
        String location = binding.etLocation.getText().toString();
        String email = binding.etemail.getText().toString();
        UserModel userModel = new UserModel(firstName, lastName, email, sharedPrefManager.getUserID(), uri, city, location);

        Map<String, Object> map = new HashMap<>();

        map.put("emailAddress", email);
        map.put("userFirstName", firstName);
        map.put("userID", sharedPrefManager.getUserID());
        map.put("userLastName", lastName);
        map.put("profilePhoto", uri);
        map.put("city", city);
        map.put("userLocation", location);

        //  Log.d("profile", uri);

        //  Toast.makeText(this, uri, Toast.LENGTH_SHORT).show();


        firebaseFirestore.collection("UsersDetails").document(sharedPrefManager.getUserID()).update(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                // Toast.makeText(EditProfileActivity.this, "Data Updated", Toast.LENGTH_SHORT).show();

                firebaseAuth.getCurrentUser().updateEmail(email).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        //   Toast.makeText(EditProfileActivity.this, "Profile Updated", Toast.LENGTH_SHORT).show();
                    }
                });
                /*firebaseAuth.getCurrentUser().updatePassword(password).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(EditProfileActivity.this, "User Updated", Toast.LENGTH_SHORT).show();
                    }
                });*/
            }
        });


        finish();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedImageUri = data.getData();


            UploadTask uploadTask = storageReference.putFile(selectedImageUri);

            uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(EditProfileActivity.this, "Photo Uploaded", Toast.LENGTH_SHORT).show();
                    storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            photoURI = uri.toString();
                        }
                    });
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(EditProfileActivity.this, "Photo Upload Failed", Toast.LENGTH_SHORT).show();
                }
            });


            civProfileUpload.setImageURI(selectedImageUri);


        }
    }
}