package com.example.exsell;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.exsell.databinding.ActivityLoginBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

public class Login extends AppCompatActivity implements View.OnClickListener {
    private TextView signup;
    private Button login;

    ActivityLoginBinding binding;

    FirebaseFirestore firebaseFirestore;

    private FirebaseAuth firebaseAuth;

    private SharedPrefManager sharedPrefManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getSupportActionBar().hide();

        sharedPrefManager = new SharedPrefManager(this);
        firebaseFirestore = FirebaseFirestore.getInstance();


        firebaseAuth = FirebaseAuth.getInstance();

        signup = (TextView) findViewById(R.id.tvSignup);
        signup.setOnClickListener(this);
        login = (Button) findViewById(R.id.btnLogin);
        login.setOnClickListener(this::onClick);
        EditText myEditText = findViewById(R.id.etusername);
        myEditText.setElevation(8f);

        binding.forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this,ActivityForgrtPassword.class));
            }
        });
        if (sharedPrefManager.isLoggedIn()) {
            startActivity(new Intent(Login.this, bottom_navigation_menu.class));
            finish();
        }

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tvSignup:
                startActivity(new Intent(this, Signup.class));
                break;

        }

        switch (v.getId()) {
            case R.id.btnLogin:
                String email = binding.etusername.getText().toString();
                String password = binding.etpassword.getText().toString();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(this, "Please fill", Toast.LENGTH_SHORT).show();
                } else {

                    /*firebaseFirestore.collection("UsersDetails").document(userID).set(userModel).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(Signup.this, "User Added", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Signup.this, Login.class));
                            finish();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(Signup.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });*/

                    firebaseAuth.getInstance().signOut();



                    firebaseFirestore.collection("UsersDetails")
                            .whereEqualTo("emailAddress",email)
                            .whereEqualTo("password",password)
                            .get()
                                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                        @Override
                                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {



                                            if (!queryDocumentSnapshots.isEmpty()) {
                                                queryDocumentSnapshots.getDocuments().forEach(documentSnapshot -> {

                                                    UserModel userModel= documentSnapshot.toObject(UserModel.class);


                                                    Toast.makeText(Login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                                    sharedPrefManager.loggedIn(true);
                                                    sharedPrefManager.setUserID(documentSnapshot.getId());
                                                    sharedPrefManager.saveUser(userModel);
                                                    startActivity(new Intent(Login.this, bottom_navigation_menu.class));
                                                    finish();


                                                });
                                            }


                                        }
                                    })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(Login.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });

                    /*firebaseAuth.signInWithEmailAndPassword(email, password)
                            .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            Toast.makeText(Login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                            sharedPrefManager.loggedIn(true);
                            sharedPrefManager.setUserID(authResult.getUser().getUid().toString());
                            startActivity(new Intent(Login.this, bottom_navigation_menu.class));
                            finish();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(Login.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });*/

                }
                break;

        }


    }

    public void forgotPassword(View view) {
        Toast.makeText(this, "Clicked", Toast.LENGTH_SHORT).show();
    }
}
