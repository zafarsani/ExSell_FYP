package com.example.exsell.ui.home;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.exsell.MainActivity;
import com.example.exsell.MyAdapter;
import com.example.exsell.MyProductsAdapter;
import com.example.exsell.SharedPrefManager;
import com.example.exsell.data.model.ProductModel;
import com.example.exsell.databinding.FragmentHomeBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HomeFragment extends Fragment implements MyAdapter.OnItemClickListener {


    ProgressDialog progressDialog ;

    private FragmentHomeBinding binding;
    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;

    private StorageReference storageReference;
    private FirebaseStorage firebaseStorage;

    private List<ProductModel> productModelList;

    private FirebaseFirestore firebaseFirestore;

    private SharedPrefManager sharedPrefManager;
    private MyAdapter myAdapter;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        sharedPrefManager = new SharedPrefManager(requireContext());

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();
        productModelList = new ArrayList<>();

        progressDialog = new ProgressDialog(getContext());

        binding.rvProducts.setLayoutManager(new LinearLayoutManager(getActivity()));
        getProducts();

        return root;
    }


    public void getProducts() {
        firebaseFirestore.collection("Products").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if (!queryDocumentSnapshots.isEmpty()) {
                    queryDocumentSnapshots.getDocuments().forEach(documentSnapshot -> {
                        if (Objects.equals(documentSnapshot.getString("userID"), sharedPrefManager.getUserID())) {

                            ProductModel productModel=documentSnapshot.toObject(ProductModel.class);
                            productModel.setDocID(documentSnapshot.getId());
                            productModelList.add(productModel);

                        }
                    });
                }
                myAdapter = new MyAdapter( getContext(),2, productModelList);
                myAdapter.setOnItemClickListener(HomeFragment.this);
                binding.rvProducts.setAdapter(myAdapter);


            }
        });


    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }




    public void updateProduct(ProductModel productItem) {

        progressDialog.show();
        firebaseFirestore.collection("Products").document(productItem.getDocID()).update("status",productItem.getStatus())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        progressDialog.dismiss();
                        //myAdapter.notifyDataSetChanged();
                        Toast.makeText(getActivity(), "Status Updated", Toast.LENGTH_SHORT).show();
                    }
                });



    }

    public void deleteProduct(int position, ProductModel productItem) {

        progressDialog.show();
        firebaseFirestore.collection("Products").document(productItem.getDocID()).delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        progressDialog.dismiss();
                        myAdapter.notifyItemRemoved(position);
                        Toast.makeText(getActivity(), "Deleted!", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    @Override
    public void onItemClick(ProductModel productItem) {

    }

    @Override
    public void onCartClick(ProductModel productItem) {

    }

    @Override
    public void onStatusClick(ProductModel productItem) {

        updateProduct(productItem);
    }

    @Override
    public void onDeleteClick(int position, ProductModel productItem) {
        deleteProduct(position,productItem);
    }



}