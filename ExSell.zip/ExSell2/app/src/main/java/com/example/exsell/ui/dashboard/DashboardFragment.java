package com.example.exsell.ui.dashboard;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.exsell.ActivityCart;
import com.example.exsell.MainActivity;
import com.example.exsell.MyAdapter;
import com.example.exsell.R;
import com.example.exsell.SharedPrefManager;
import com.example.exsell.data.model.ProductModel;
import com.example.exsell.databinding.FragmentDashboardBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class DashboardFragment extends Fragment implements MyAdapter.OnItemClickListener {


    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;
    ProgressDialog progressDialog ;


    private StorageReference storageReference;
    private FirebaseStorage firebaseStorage;

    private List<ProductModel> productModelList;

    private FirebaseFirestore firebaseFirestore;

    private MyAdapter myAdapter;
    private SharedPrefManager sharedPrefManager;

    private FragmentDashboardBinding binding;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        DashboardViewModel dashboardViewModel =
                new ViewModelProvider(this).get(DashboardViewModel.class);

        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        progressDialog = new ProgressDialog(getContext());
        sharedPrefManager = new SharedPrefManager(requireContext());

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();
        storageReference = firebaseStorage.getReference();
        productModelList = new ArrayList<>();

        binding.rvProducts.setLayoutManager(new LinearLayoutManager(getActivity()));

        getProducts();



        binding.imgCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), ActivityCart.class));
            }
        });


        return root;
    }

    public void addTextListener() {
        binding.etSearchProduct.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                myAdapter.filter(charSequence.toString().toLowerCase());

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public void getProducts() {
        firebaseFirestore.collection("Products").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if (!queryDocumentSnapshots.isEmpty()) {
                    queryDocumentSnapshots.getDocuments().forEach(documentSnapshot -> {

                        ProductModel tempProductModel= documentSnapshot.toObject(ProductModel.class);

                        tempProductModel.setDocID(documentSnapshot.getId());
                        if(tempProductModel.getStatus().equals("Available"))
                        {
                            productModelList.add(tempProductModel);
                        }
                    });
                }
                myAdapter = new MyAdapter(getContext(),1,productModelList);
                myAdapter.setOnItemClickListener(DashboardFragment.this);
                binding.rvProducts.setAdapter(myAdapter);
                myAdapter.notifyDataSetChanged();

                addTextListener();

            }
        });


    }


    public void addCart(ProductModel productModel) {



        progressDialog.show();
        productModel.setClientID(sharedPrefManager.getUserID());
        firebaseFirestore.collection("Cart").document(productModel.getDocID()).set(productModel)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        progressDialog.dismiss();
                        Toast.makeText(getActivity(), "Product Add to cart!", Toast.LENGTH_SHORT).show();
                        /*startActivity(new Intent(getActivity(), MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        getActivity().finish();*/
                    }
                });

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onItemClick(ProductModel productItem) {

        Bundle bundle = new Bundle();
        bundle.putParcelable("productItem", productItem);




        NavController navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment_activity_bottom_navigation_menu);
        navController.navigate(R.id.action_navigation_dashboard_to_productDetailsFragment, bundle);
    }

    @Override
    public void onCartClick(ProductModel productItem) {
        addCart(productItem);
    }

    @Override
    public void onStatusClick(ProductModel productItem) {

    }

    @Override
    public void onDeleteClick(int position, ProductModel productItem) {

    }
}