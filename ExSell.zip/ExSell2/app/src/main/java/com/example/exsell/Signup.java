package com.example.exsell;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.exsell.databinding.ActivitySignupBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.time.LocalDate;

public class Signup extends AppCompatActivity {

    ActivitySignupBinding binding;
    FirebaseAuth firebaseAuth;
    FirebaseFirestore firebaseFirestore;

    private UserModel userModel;

    String email;
    String password;
    String confirmPassword;
    String userFirstName;
    String userLastName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        getSupportActionBar().hide();


        userModel = new UserModel();
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();




        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                email = binding.etemail.getText().toString();
                password = binding.etpassword.getText().toString();
                confirmPassword = binding.etconfirmpassword.getText().toString();
                userFirstName = binding.etUserfname.getText().toString();
                userLastName = binding.etuserlname.getText().toString();


                if (password.equals(confirmPassword)) {

                    firebaseAuth.createUserWithEmailAndPassword(email, password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            Toast.makeText(Signup.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                            createUser(email, password, authResult.getUser().getUid());
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(Signup.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                } else
                    Toast.makeText(Signup.this, "Password does not Match", Toast.LENGTH_SHORT).show();

            }


        });


    }

    private void createUser(String email, String password, String userID) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            userModel = new UserModel(userFirstName, userLastName, password, email, userID, LocalDate.now().toString());
        }
        firebaseFirestore.collection("UsersDetails").document(userID)
                .set(userModel).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(Signup.this, "User Added", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Signup.this, Login.class));
                finish();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Signup.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });




    }

}
