package com.example.exsell;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.exsell.data.model.ProductModel;
import com.example.exsell.ui.dashboard.DashboardFragment;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    private List<ProductModel> data;
    private List<ProductModel> filteredList;

    Context context;

    private int from; // 1= dashboard/ 2= Home/ 3= Activity Cart/
    public MyAdapter( Context context, int from, List<ProductModel> data) {
        this.data = data;
        this.filteredList = new ArrayList<>(data);
        this.from=from;
        this.context=context;

    }


    @SuppressLint("NotifyDataSetChanged")
    public void filter(String searchText) {
        filteredList.clear();
        if (TextUtils.isEmpty(searchText)) {
            filteredList.addAll(data);
        } else {
            String query = searchText.toLowerCase();
            for (ProductModel item : data) {
                if (item.getProductName().toLowerCase().contains(query)) {
                    filteredList.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(ProductModel productItem);
        void onCartClick(ProductModel productItem);
        void onStatusClick(ProductModel productItem);
        void onDeleteClick(int position, ProductModel productItem);

    }

    private OnItemClickListener listener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.product_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {



        ProductModel item;
        if(from==1) // home
        {
            holder.switchStatus.setVisibility(View.GONE);
            holder.imgDelete.setVisibility(View.GONE);
        }
        else if(from==2) // dashboard
        {
            holder.imgCart.setVisibility(View.GONE);
        }
        else if(from==3) // cart
        {
            holder.switchStatus.setVisibility(View.GONE);
            holder.imgCart.setVisibility(View.GONE);
            holder.imgDelete.setVisibility(View.GONE);
        }

        if (data.size() != filteredList.size()) {
            item = filteredList.get(position);
        } else {
            item = data.get(position);
        }
        holder.titleTextView.setText(item.getProductPrice() + " Rs");
        holder.descriptionTextView.setText(item.getProductName());
        holder.userLocation.setText(item.getCity());
        holder.tvCTG.setText(item.getCtg());
        Glide.with(holder.itemView.getContext()).load(item.getImage1()).into(holder.imageView);

        if(item.getStatus().equals("Available")) holder.switchStatus.setChecked(true);
        else holder.switchStatus.setChecked(false);
        holder.imgCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onCartClick(item);
                }
            }
        });
        holder.layItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(from==3){

                    Activity activity = (Activity) context;

                    Bundle bundle = new Bundle();
                    bundle.putParcelable("productItem", item);


                    /*Bundle bundle = new Bundle();
                    bundle.putParcelable("productItem", item);
                    DashboardFragment fragobj = new DashboardFragment();
                    fragobj.setArguments(bundle);
                    context.startActivity(new Intent(context, ActivityCart.class).putExtra ("productItem", item));*/

                }


                if (listener != null) {
                    listener.onItemClick(item);
                }
            }
        });
        holder.imgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onDeleteClick(position, item);
                }
            }
        });


        holder.switchStatus.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked==true){
                    item.setStatus("Available");
                    if (listener != null) {
                        listener.onStatusClick(item);
                    }
                }
                else if(isChecked==false){
                    item.setStatus("NA");
                    if (listener != null) {
                        listener.onStatusClick(item);
                    }
                }


            }
        });
    }

    @Override
    public int getItemCount() {

        int size;

        if (data.size() != filteredList.size()) {
            size = filteredList.size();
        } else size = data.size();
        return size;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView titleTextView,tvCTG;
        public TextView descriptionTextView;
        public TextView userLocation;
        public ImageView imageView,imgCart,imgDelete;
        public Switch switchStatus;
        public RelativeLayout layItem;

        public ViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.tvPrice);
            tvCTG = itemView.findViewById(R.id.tvCTG);
            descriptionTextView = itemView.findViewById(R.id.tvTitle);
            imageView = itemView.findViewById(R.id.imageProduct);
            imgCart = itemView.findViewById(R.id.imgCart);
            imgDelete = itemView.findViewById(R.id.imgDelete);
            userLocation = itemView.findViewById(R.id.tvUserLocation);
            switchStatus = itemView.findViewById(R.id.switchStatus);
            layItem = itemView.findViewById(R.id.layItem);

        }
    }
}